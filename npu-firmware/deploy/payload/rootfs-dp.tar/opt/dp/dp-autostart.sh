#!/bin/sh
# XGS116 NPU p3 data-plane auto-start. Invoked BACKGROUNDED from rcS after the EP
# mgmt plane is up. Loads the MUSDK/pp2/dmax UIO modules, brings up the 88E6193X
# switch natively (no libsbsp): CPU port(0) -> 4-byte DSA (so every frame to the
# NPU carries its ingress switch-port, which dp_fwd maps to the pport tag), each of
# the 8 front copper ports VLAN-mapped to the CPU only (isolated), and all 8 front
# PHYs powered up. Then execs dp_fwd (the giu<->pp2 forwarder), which blocks in
# nmp_init until the x86 host driver asserts HOST_MGMT_READY -- so it is safe to
# start before the host is up. Do NOT ifconfig up mvmgmt0 (pcinet TX crash open).
DP=/opt/dp
S=$DP/swmdio.sh
log() { echo "[dp-autostart] $*"; }

# --- D84 one-shot candidate selection, for EVERY persisted NPU change (DEBT #116) ----------------
#
# The arm-marker pattern below used to guard `dp_fwd` alone. `sw-init.sh` and `sfp-init.sh` had no
# candidate path at all — they were edited in place on the read-only rootfs or replaced wholesale,
# so a change to either was armed by the NEXT MAINS LOSS on a processor with no A/B and no
# auto-revert, and nothing could say a change was staged. DEBT #67's `sfp-init.sh` sat in exactly
# that state until a 2026-08-28 mains cut happened to test it.
#
# /persistent is mounted ONCE, here, because all three selections need it and the mount is the
# expensive part. THE ORDERING IS LOAD-BEARING: the previous version mounted it at the bottom, so
# adding earlier mounts naively would make that `if mount ...` fail (already mounted), silently
# skipping the dp_fwd candidate — a change that looks like it extends the guard while removing it.
DP_DEV=/dev/mmcblk0p4
DP_MNT=/persistent
PERSIST=no

# THE MOUNT SAYS WHICH OF THREE THINGS HAPPENED, ALWAYS (DEBT #152).
#
# The previous form was `mount … 2>/dev/null && PERSIST=yes`: the error was discarded, PERSIST
# stayed `no` for the whole boot, arm_candidate() returned immediately for every file, and NOTHING
# ANYWHERE SAID THE SAFETY NET WAS ABSENT. A boot with no rollback looked identical to a boot with
# one — on a processor with no A/B, whose only recovery is a mains cycle.
#
# `2>/dev/null` was not gratuitous, which is why this captures instead of simply removing it: mount
# writes a real diagnostic on a genuinely absent device and that used to land in the console mid
# bring-up. So the error is CAPTURED and re-emitted through log(), where rcS's redirect
# (/tmp/dp-autostart.log) carries it like every other line.
#
# THREE OUTCOMES, THREE MESSAGES, and the failing one names the consequence rather than the errno
# alone — a reader who finds `mount: ...: No such device` in a boot log should not have to know
# what it costs. Note the eMMC has enumerated long before this runs: the kernel `rootwait`s for
# mmcblk0p3 on the SAME device, so a failure here is a real fault and not a race to retry.
_mnterr=$(mount -o rw "$DP_DEV" "$DP_MNT" 2>&1) && PERSIST=yes
if [ "$PERSIST" = yes ]; then
    log "persistent store MOUNTED ($DP_DEV -> $DP_MNT); candidate arming is available"
else
    log "WARNING: $DP_DEV did NOT mount on $DP_MNT: ${_mnterr:-no error text}"
    log "WARNING: PERSIST=no — NO candidate can be armed and there is NO rollback store this boot."
    log "WARNING: everything below runs the SHIPPED file. That is safe, and it is not the same as"
    log "WARNING: a boot that had a safety net and did not need it. DEBT #152."
fi

# arm_candidate <name> -> echoes the path to run, or nothing if the incumbent should run.
#
# Consumes the marker BEFORE the candidate runs, exactly as the dp_fwd selector does and for the
# same reason: a bad candidate in PERSISTENT storage would otherwise survive the mains cycle that is
# the only cure. One shot, then the next boot falls back with no human action.
#
# Every failure path falls through to the incumbent: no /persistent, no candidate, not readable, no
# marker. Silence from this function means "run the shipped one".
arm_candidate() {
    _n="$1"
    [ "$PERSIST" = yes ] || return 0
    [ -f "$DP_MNT/dp/$_n" ] || return 0
    [ -f "$DP_MNT/dp/$_n.arm" ] || return 0
    rm -f "$DP_MNT/dp/$_n.arm"; sync
    # STDERR, not stdout. This function returns its answer by echoing a path into `$( )`, so a
    # log line on stdout is CAPTURED INTO THE PATH and the caller runs a nonexistent file. It
    # fires only on the ARMED branch — the one boot that matters, on a processor whose only
    # recovery is a mains cycle. Caught by the extracted-function control, not by review.
    log "candidate ARMED -> $DP_MNT/dp/$_n (marker consumed; next boot falls back)" >&2
    echo "$DP_MNT/dp/$_n"
}

log "loading UIO modules"
cd "$DP/modules" || exit 1
insmod musdk_cma.ko 2>/dev/null
insmod mv_dmax2_uio.ko 2>/dev/null
insmod uio_pdrv_genirq.ko of_id=generic-uio 2>/dev/null

log "switch base init"
_c=$(arm_candidate sw-init.sh); sh "${_c:-$DP/sw-init.sh}"

log "switch: CPU DSA + per-port VLAN maps + front PHY power-up (ports 1-8)"
sh "$S" wr 0 4 0x17f            # CPU port(0) -> 4-byte DSA
sh "$S" wr 0 6 0x3fe            # CPU VLAN map -> the NINE front ports 1-9 (DEBT #151)
for p in 1 2 3 4 5 6 7 8; do
	sh "$S" wr "$p" 4 0x7f     # front port forwarding
	sh "$S" wr "$p" 6 0x001    # front port VLAN map -> CPU only (isolate)
	# power up the front copper PHY p (Global2 SMI-PHY C22: reg0 = 0x9140)
	sh "$S" wr 0x1c 0x19 0x0000; sh "$S" wr 0x1c 0x18 $((0x9400 | (p << 5) | 0x16))
	sh "$S" wr 0x1c 0x19 0x9140; sh "$S" wr 0x1c 0x18 $((0x9400 | (p << 5) | 0x00))
done

# PortF1 / SFP (switch port 9, SerDes lane 9). NOT in the loop above: that loop stops at 8
# and does a C22 PHY write, and port 9 has no integrated PHY -- it is a C45 SerDes lane.
# MUST run after the VLAN maps above (D53-5 ordering). DEBT #67.
_c=$(arm_candidate sfp-init.sh); sh "${_c:-$DP/sfp-init.sh}"

ifconfig eth0 up 2>/dev/null

log "starting dp_fwd (blocks until host HOST_MGMT_READY)"
cd "$DP" || exit 1

# --- D84 persistent candidate selector (Mamoru, DEBT: NPU deploy path) ---------------
# Prefer a candidate dp_fwd from the persistent partition for exactly ONE boot, else run the
# immutable rootfs binary. Every failure path falls through to the incumbent: p4 absent, mount
# refused, candidate missing, candidate not executable, marker absent.
#
# THE ARM MARKER IS CONSUMED BEFORE EXEC, and that is the load-bearing part. A bad dp_fwd is
# healed today by a mains cycle, which works by wiping /tmp — so a candidate living in PERSISTENT
# storage would survive the very cure. One-shot means a candidate runs once and the next boot
# falls back with no human action. Same shape as RAUC BootNext, one layer down.
#
# /opt/dp/dp_fwd is never written by this and stays immutable (the rootfs is ext4 ro), which is
# what dp-swap-guarded.sh's rollback reasoning and the mains-cycle recovery both rest on.
# Uses the single mount taken at the top (DEBT #116) rather than mounting again — a second
# `mount` of an already-mounted device fails, and the previous shape treated that failure as
# "no candidate", so it would have silently stopped arming the moment anything else mounted first.
#
# The executable test stays here and NOT in `arm_candidate`: `dp_fwd` must be executable to be
# exec'd, while `sw-init.sh`/`sfp-init.sh` are handed to `sh` and need only be readable. Folding
# them into one test would either reject a valid script candidate or accept a non-executable
# binary — a distinction worth two lines.
DP_BIN=./dp_fwd
_c=$(arm_candidate dp_fwd)
if [ -n "$_c" ] && [ -x "$_c" ]; then
    DP_BIN="$_c"
elif [ -n "$_c" ]; then
    log "WARN: candidate dp_fwd is not executable — running the shipped binary (marker was consumed)"
fi
# Release /persistent unless dp_fwd itself is about to run from it. A script candidate has already
# been read and run by here, so only the binary needs the mount held across the exec.
case "$DP_BIN" in
    "$DP_MNT"/*) : ;;
    *) [ "$PERSIST" = yes ] && umount "$DP_MNT" 2>/dev/null ;;
esac
log "starting dp_fwd from $DP_BIN"
exec env LD_LIBRARY_PATH=/lib:/usr/lib "$DP_BIN" -g 2 -i eth0 -c 1 -a 1 -f dp-nmp-config.txt --no-stat
